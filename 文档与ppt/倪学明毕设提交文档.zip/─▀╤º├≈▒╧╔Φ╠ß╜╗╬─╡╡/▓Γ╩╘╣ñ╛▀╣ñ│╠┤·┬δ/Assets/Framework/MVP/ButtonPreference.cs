﻿using UnityEngine;

namespace Framework.MVP
{
    public class ButtonPreference : MonoBehaviour
    {
        public float PressScale = 1.0f;
        public string ClickSfx;
    }
}
