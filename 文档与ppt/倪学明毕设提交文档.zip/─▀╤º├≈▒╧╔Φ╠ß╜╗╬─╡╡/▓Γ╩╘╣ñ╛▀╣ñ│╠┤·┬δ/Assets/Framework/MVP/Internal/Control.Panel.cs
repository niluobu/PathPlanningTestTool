﻿using UnityEngine;

namespace Framework.MVP.Internal
{
    internal class Panel : Control<RectTransform>, IPanel { }
}
