﻿using UnityEngine;

namespace Framework.MVP
{
    public class TextPreference : MonoBehaviour
    {
        public string LocalizationKey = string.Empty;
        public string FontName = string.Empty;
    }
}
