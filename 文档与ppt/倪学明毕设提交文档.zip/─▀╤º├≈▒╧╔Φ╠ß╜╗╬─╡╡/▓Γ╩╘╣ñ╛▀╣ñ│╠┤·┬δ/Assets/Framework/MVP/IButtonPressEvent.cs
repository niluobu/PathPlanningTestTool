﻿using System;

namespace Framework.MVP
{
    public interface IButtonPressEvent : IObservable<ButtonPreference> { }
}
