﻿namespace Framework.MVP
{
    public interface IAnimator
    {
        void Play(string stateName);
    }
}
